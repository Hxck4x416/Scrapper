from telethon import TelegramClient, events
from telebot import TeleBot
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
import re
import time
import requests
import random

Token = "7940797719:AAFF8QvsVgyZIQKUn09xk0_CzUxxgNfLu7o"
id_channel = -1002280989123  # ID de tu canal objetivo

api_id = 28193099
api_hash = '6f8d632d5e85e2abbba87e297141c34a'

client = TelegramClient('hxck', api_id, api_hash)
client.parse_mode = 'html'

bot = TeleBot(Token, parse_mode="html")

def verificar(ccn):
    # Verificar la tarjeta en tu base de datos
    with open('/storage/emulated/0/SCDAPPEORD/tarjetas.txt', 'r') as f:
        tarjetas = f.readlines()
    
    for tarjeta in tarjetas:
        tarjeta = tarjeta.strip()  # Eliminar espacios en blanco y caracteres especiales
        if ccn == tarjeta:
            return True
    
    return False

def obtener_tipo_gateway(texto):
    # Buscar 'Gateway ➣' seguido del tipo de gateway o 'Response » Approved! ✅' seguido del tipo de gateway
    match_gateway = re.search(r"'Gateway ➣[^\w]*(\w+)', 'Response » Approved! ✅[^\w]*(\w+)', '━━━━━━━━━━━━━[^\w]*(\w+)|ʙɪɴ »[^\w]*(\w+)', '✠═════════════⚔️═════════════✠[^\w]*(\w+)', '𝗡𝗠𝗕 𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅ [^\w]*(\w+)'", texto)
    
    if match_gateway:
        # Devuelve el tipo de gateway que se haya encontrado
        return match_gateway.group(1) or match_gateway.group(2)
    
    return None

@client.on(events.NewMessage)
async def my_event_handler(event):
    text = event.raw_text

    if "|" in text:
        x = re.findall(r'\d+', text)
        if len(x) < 4:
            print(f'! Tarjeta no detectada\n')
            return
        cc = x[0]
        mm = x[1]
        yy = x[2]
        cvv = x[3]
        if len(cc) > 16:
            return
        if len(mm) > 11:
            return
        if len(yy) > 4:
            return
        if len(cvv) > 4:
            return
        cxc = f"{cc}"
        if mm.startswith('2'):
            mm, yy = yy, mm
        if len(mm) >= 3:
            mm, yy, cvv = yy, cvv, mm
        if len(cc) < 15 or len(cc) > 16:
            print(f'! Tarjeta invalida\n')
            return
        if len(yy) == 2:
            yy = '20' + yy

        tarj = f'{cc}|{mm}|{yy}|{cvv}'
        v = verificar(cc)
        if v == True:
            print(f'{tarj} Esta tarjeta ya existe en la base de datos')
            return
        tarj = f'{cc}|{mm}|{yy}|{cvv}'
        with open('tarjetas.txt', 'a') as d:
            d.write(tarj + "\n")

        # res = gate(cc, mm, yy, cvv)
        if 'Approved' == 'Approved':
            mes = '✅ Approved - ' + tarj + ''
            photo_path = "/storage/emulated/0/SCDAPPEORD/Jsjs.jpg"  # Ruta de la imagen que deseas enviar

            bin = cxc[0:6]
            rs = requests.get(f"https://bins.antipublic.cc/bins/{bin}").json()
            country = rs["country_name"]
            flag = rs["country_flag"]
            bank = rs["bank"]
            brand = rs["brand"]
            type = rs["type"]
            level = rs["level"]

            lines = text.split("\n")  #split message
            gateway = ""  # store gateway
            for line in lines:  # check every lines
                if "Gateway" in line:
                    gateway = obtener_tipo_gateway(line)
                    if gateway:
                        gateway = f"Gateway ➵ {gateway}"
                    break

            status = "APROVEDD"  # Definir el valor de la variable status
            gateway = "APROVEDD"

            text = f"""
❖ <b>SCRAPP HXCK4X4</b>❖
<b>↓→𝘾𝙖𝙧𝙙: </b> <code>{cc}|{mm}|{yy}|{cvv}</code>
<b>↓→𝙎𝙩𝙖𝙩𝙪𝙨: ↳ </b> {status} ❇️
↓→𝙍𝙚𝙨𝙥𝙤𝙣𝙨𝙚: ↳ <code>{gateway}</code>
━━━━━━━━━━━━
<b>↓→𝙄𝙣𝙛𝙤: </b> #Bin{bin}  - <code>{brand}</code> - <code>{level}</code> - <code>{type}</code>
<b>↓→𝘽𝙖𝙣𝙠: </b> <code>{bank}</code>
<b>↓→𝘾𝙤𝙪𝙣𝙩𝙧𝙮: </b> <code>{country} - [{flag}]</code>
❖ <b>↓→𝙀𝙭𝙩𝙧𝙖: </b> <code>{cxc[0:12]}xxxx|{mm}|{yy}|xxx</code> 
           ━━━━━ [Scrapper Hxck4x4] ━━━━━
            """

            print(f'$ Mensaje enviado -> {cc}|{mm}|{yy}|{cvv}\n')
            time.sleep(0.5)
            
            # Crear el teclado en línea
            keyboard = InlineKeyboardMarkup()
            button_owner = InlineKeyboardButton("OWNER", url="https://t.me/user1538837")
            button_semiowner = InlineKeyboardButton("SEMI OWNER", url="t.me/user1538837")
            button_chat = InlineKeyboardButton("CHAT VIP", url="https://t.me/user1538837")
            keyboard.add(button_owner, button_semiowner, button_chat)

            with open('/storage/emulated/0/SCDAPPEORD/Jsjs.jpg', 'rb') as photo:
                bot.send_photo(id_channel, photo, caption=text, reply_markup=keyboard)
        else:
            pass

card_regex = re.compile(r'\b(?:\d[ -]*?){13,19}\b')  # Expresión regular para números de tarjeta
date_regex = re.compile(r'\b(\d{2})[/.,-](\d{2})[/.,-](\d{2}|\d{4})\b')  # Expresión regular para fechas de vencimiento
cvv_regex = re.compile(r'\b\d{3,4}\b')  # Expresión regular para CVV

def custom_function(card_number, expiration_month, expiration_year, cvv):
    # Validar la tarjeta de crédito
    if validate_credit_card(card_number):
        print(f'Tarjeta detectada -> {card_number}|{expiration_month}|{expiration_year}|{cvv}')
    else:
        print('Tarjeta inválida')

def validate_credit_card(card_number):
    # Realizar la validación de la tarjeta de crédito (puedes implementar tu lógica de validación aquí)
    # Por ejemplo, puedes utilizar bibliotecas como "pycard" o "pycreditcard"
    # Devuelve True si la tarjeta es válida, False en caso contrario.
    return True

@client.on(events.NewMessage)
async def my_event_handler(event):
    text = event.raw_text

    if "|" in text:
        x = re.findall(r'\d+', text)
        if len(x) < 4:
            print(f'Tarjeta no detectada\n')
            return
        cc = x[0]
        mm = x[1]
        yy = x[2]
        cvv = x[3]


print("PROGRAMA INICIADO TLG\nVERSION: 2.0\n")

client.start()
client.run_until_disconnected()